"use strict";
window.NewGame.state.menu = {
	create: function(){
		// you can create menu group in map editor and load it like this:
		// mt.create("menu");
		var logo = mt.create("logo");
		var movies = mt.createMovies(logo);
		movies.NewMovie.start().loop();
		this.game.stage.disableVisibilityChange = true;
	},
	
	update: function(){
		
	}
};