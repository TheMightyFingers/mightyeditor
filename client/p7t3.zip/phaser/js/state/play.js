"use strict";
window.NewGame.state.play = {
	preload: function(){
		
	},
	
	create: function(){
		console.log("started pplay state");
	},
	
	update: function(){
		
	}
};